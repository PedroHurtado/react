import { sum, mult,divide,resta } from "./operations.js";
import './pages/menu.js'

/*/import pg1 from './pages/pagina1.js'
import pg2 from './pages/pagina2.js'
import pg3 from './pages/pagina3.js'*/

console.log(sum(5,3)) //8
console.log(mult(5,3)) //15
console.log(divide(4,2)) //2
console.log(resta(5,3)) //15

//pg1()
//pg2()
//pg3()
