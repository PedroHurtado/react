export default function pagina2(){
    console.log("Pagina2")
}