export default function pagina1(){
    console.log("Pagina1")
}