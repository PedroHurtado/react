export default function pagina3(){
    console.log("Pagina3")
}