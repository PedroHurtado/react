async function loadPage(url){
    const module = await import(url);
    module.default();
}
function Menu(){
    document.addEventListener('click',(ev)=>{
        ev.preventDefault();
        let pagina =  ev.target.href;
        if(pagina){
            pagina =  `./${new URL(pagina).hash.substring(1)}.js`
            loadPage(pagina)
        }
        
    })
}
Menu();

