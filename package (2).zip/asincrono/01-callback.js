//anterior al 2015

class CustomerService{
    static get(id,cb){
        if(id===1){
            cb(null,{id})  //ok
        }
        else{
            cb("el cliente no existe", null) //error
        }
    }
}

class InvoicesCustomerService{
    static get(clientId,cb){
        if(clientId===1){
            cb(null,{clientId, invoices:[]})
        }
        else{
            cb("El cliente no tiene facturas" ,null)
        }
    }
}

function main(id){
    CustomerService.get(id,(error,data)=>{
        if(error){
            console.log(error)
        }
        else{
            InvoicesCustomerService.get(data.id,(error,data)=>{
                if(error){
                    console.log(error)
                }
                else{
                    console.log(data)
                }
            })
        }
    })
}

main(1) //OK
main(2) //ERROR