//código asincrono >2017

class CustomerService{    
    static async  get(id){
        if(id===1){
            return {id}
        }
        throw new Error("el cliente no existe")
    }    
}

class InvoicesCustomerService{
    static get(clientId){
        return new Promise((resolve,reject)=>{
            if(clientId===1){
                resolve({clientId,invoices:[]})
            }
            else{
                reject("El cliente no tiene facturas")
            }
        })
    }
}

async function main(id){
   try{
     const customer = await CustomerService.get(id)
     const invoices = await InvoicesCustomerService.get(customer.id)
     console.log(invoices)
   }
   catch(error){
    console.log(error)
   }
}

main(1) //OK
main(2) //ERROR