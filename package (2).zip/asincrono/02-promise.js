//código asincrono >2015

class CustomerService{
    static get(id){
        return new Promise((resolve,reject)=>{
            if(id===1){
                resolve({id})
            }
            else{
                reject("El cliente no existe")
            }
        })        
    }
}

class InvoicesCustomerService{
    static get(clientId){
        return new Promise((resolve,reject)=>{
            if(clientId===1){
                resolve({clientId,invoices:[]})
            }
            else{
                reject("El cliente no tiene facturas")
            }
        })
    }
}

function main(id){
   CustomerService.get(id)
    .then(customer=> InvoicesCustomerService.get(customer.id))
    .then(invoices=>console.log(invoices))
    .catch(error=>console.log(error))
}

main(1) //OK
main(2) //ERROR